package fr.robie.machineengine.core.resource;

import fr.robie.machineengine.api.MachineEngineKeys;
import fr.robie.machineengine.api.addon.AddonId;
import fr.robie.machineengine.api.data.VersionedCodec;
import fr.robie.machineengine.api.diagnostic.Diagnostic;
import fr.robie.machineengine.api.diagnostic.DiagnosticCodes;
import fr.robie.machineengine.api.diagnostic.ValidationContext;
import fr.robie.machineengine.api.diagnostic.Validator;
import fr.robie.machineengine.api.registry.Registries;
import fr.robie.machineengine.api.registry.Registry;
import fr.robie.machineengine.api.registry.RegistryType;
import fr.robie.machineengine.api.resource.Fluids;
import fr.robie.machineengine.api.resource.ResourceComponentType;
import fr.robie.machineengine.api.resource.ResourceType;
import fr.robie.machineengine.api.resource.convert.ResourceConverter;
import fr.robie.machineengine.api.resource.tag.ResourceTagContribution;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.key.Keyed;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Validators for MachineEngine's own registries (§24). */
public final class BuiltInValidators {
    /** Namespaces only MachineEngine itself may register into. */
    public static final Set<String> RESERVED_NAMESPACES = Set.of(MachineEngineKeys.NAMESPACE, Key.MINECRAFT_NAMESPACE);

    private BuiltInValidators() {
    }

    /** Validators for static registries; they run at startup. */
    public static List<Validator> staticValidators() {
        return List.of(
                BuiltInValidators::reservedNamespaces,
                BuiltInValidators::aliases,
                BuiltInValidators::resourceTypes,
                BuiltInValidators::converters,
                BuiltInValidators::codecs,
                MachineValidators::machineTypes,
                MachineValidators::upgradeTypes,
                MachineValidators::transportTypes);
    }

    /** Validators for one reloadable registry; they run whenever it is (re)built. */
    public static List<Validator> reloadValidators(RegistryType<?> type) {
        if (type.equals(Registries.RESOURCE_TAG)) return List.of(BuiltInValidators::tags);
        if (type.equals(Registries.RECIPE)) return List.of(MachineValidators::recipes);
        return List.of();
    }

    /** An alias points to an entry of its registry, not to another alias. */
    private static void aliases(ValidationContext context) {
        for (RegistryType<?> type : context.registries().types()) {
            if (type.isReloadable()) continue;
            Registry<?> registry = context.registries().registry(type);
            for (Map.Entry<Key, Key> alias : registry.aliases().entrySet()) {
                Key from = alias.getKey();
                Key to = alias.getValue();
                String problem = null;
                if (registry.aliases().containsKey(to)) {
                    problem = "The alias " + from.asString() + " points to another alias, " + to.asString() + "; point it to the entry";
                } else if (!registry.keys().contains(to)) {
                    problem = "The alias " + from.asString() + " points to " + to.asString() + ", which is not in " + type;
                }
                if (problem != null) {
                    context.report(Diagnostic.error(DiagnosticCodes.INVALID_ALIAS, problem)
                            .source(registry.owner(from).orElse(AddonId.MACHINE_ENGINE)).subject(from)
                            .with("registry", type.toString()).with("target", to.asString()).build());
                }
            }
        }
    }

    private static void reservedNamespaces(ValidationContext context) {
        for (RegistryType<?> type : context.registries().types()) {
            if (type.isReloadable()) continue;
            Registry<?> registry = context.registries().registry(type);
            List<Key> keys = new ArrayList<>(registry.keys());
            keys.addAll(registry.aliases().keySet());
            for (Key key : keys) {
                AddonId owner = registry.owner(key).orElse(null);
                if (owner != null && !owner.equals(AddonId.MACHINE_ENGINE) && RESERVED_NAMESPACES.contains(key.namespace())) {
                    context.report(Diagnostic.error(DiagnosticCodes.RESERVED_NAMESPACE,
                                    "The '" + key.namespace() + "' namespace is reserved for MachineEngine; use your own namespace")
                            .source(owner).subject(key).with("registry", type.toString()).build());
                }
            }
        }
    }

    private static void resourceTypes(ValidationContext context) {
        Registry<ResourceType> types = context.registries().registry(Registries.RESOURCE_TYPE);
        var categories = context.registries().registry(Registries.RESOURCE_CATEGORY);
        Registry<ResourceComponentType<?>> components = context.registries().registry(Registries.RESOURCE_COMPONENT_TYPE);
        for (ResourceType type : types) {
            if (!categories.containsValue(type.category())) {
                context.report(unregistered(types, type, "category " + type.category().key().asString()));
            }
            for (ResourceComponentType<?> component : type.defaultComponents().types()) {
                if (!components.containsValue(component)) {
                    context.report(unregistered(types, type, "component type " + component.key().asString()));
                }
            }
            // Pipes and ports take fluids by the global category (D29); a fluid elsewhere is almost always a mistake.
            if (type.key().value().startsWith("fluid/") && !Fluids.isFluid(type)) {
                context.report(Diagnostic.warning(DiagnosticCodes.FLUID_OUTSIDE_CATEGORY,
                                type.key().asString() + " looks like a fluid but is in " + type.category().key().asString()
                                        + ", not " + Fluids.CATEGORY_KEY.asString() + "; fluid pipes and ports will not take it."
                                        + " Create it with Fluids.create(key) or give it category " + Fluids.CATEGORY_KEY.asString())
                        .source(types.owner(type.key()).orElse(AddonId.MACHINE_ENGINE)).subject(type.key()).build());
            }
        }
    }

    private static void converters(ValidationContext context) {
        Registry<ResourceConverter> converters = context.registries().registry(Registries.RESOURCE_CONVERTER);
        Registry<ResourceType> types = context.registries().registry(Registries.RESOURCE_TYPE);
        for (ResourceConverter converter : converters) {
            if (!types.containsValue(converter.from())) {
                context.report(unregistered(converters, converter, "input type " + converter.from().key().asString()));
            }
            if (!types.containsValue(converter.to())) {
                context.report(unregistered(converters, converter, "output type " + converter.to().key().asString()));
            }
            if (converter.from() == converter.to()) {
                context.report(Diagnostic.error(DiagnosticCodes.INVALID_DEFINITION, "A converter must change the resource type")
                        .source(converters.owner(converter.key()).orElse(null)).subject(converter.key()).build());
            }
        }
    }

    private static void codecs(ValidationContext context) {
        Registry<VersionedCodec<?>> codecs = context.registries().registry(Registries.STORAGE_CODEC);
        for (VersionedCodec<?> codec : codecs) {
            for (String problem : codec.definitionProblems()) {
                context.report(Diagnostic.error(DiagnosticCodes.INVALID_CODEC, "Codec " + codec.key().asString() + ": " + problem)
                        .source(codecs.owner(codec.key()).orElse(null)).subject(codec.key()).build());
            }
        }
    }

    private static void tags(ValidationContext context) {
        Registry<ResourceTagContribution> tags = context.registries().registry(Registries.RESOURCE_TAG);
        Registry<ResourceType> types = context.registries().registry(Registries.RESOURCE_TYPE);
        for (ResourceTagContribution contribution : tags) {
            for (ResourceType member : contribution.members()) {
                if (!types.containsValue(member)) {
                    context.report(unregistered(tags, contribution, "resource type " + member.key().asString()));
                }
            }
        }
    }

    static <T extends Keyed> Diagnostic unregistered(Registry<T> registry, T entry, String what) {
        return Diagnostic.error(DiagnosticCodes.UNREGISTERED_REFERENCE,
                        entry.key().asString() + " references " + what + ", which is not registered")
                .source(registry.owner(entry.key()).orElse(null)).subject(entry.key())
                .with("registry", registry.type().toString()).build();
    }
}
